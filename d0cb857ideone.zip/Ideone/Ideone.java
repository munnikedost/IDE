import java.util.*;

public class Ideone
{
	public static void main(String[] args)
	{
		int t;
		Scanner scan = new Scanner(System.in);
		t = scan.nextInt();
		System.out.println(t);
		
	}
}
