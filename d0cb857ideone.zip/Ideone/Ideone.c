#include <stdio.h>
int main()
{
	
	getch();
   return 0;
  
}
