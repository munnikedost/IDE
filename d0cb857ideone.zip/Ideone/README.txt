file.txt is used to save the recently opened files in the application
the directory of the files may change depending upon the system